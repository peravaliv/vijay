package com.capgemini.product.validation;

public class Validate {
	
	public boolean name(String str) {
		boolean name_val = str.matches("[A-Z][a-z]*");
		if(name_val)
			return true;
		return false;
	}
	
	public boolean quant(int i1) {
		boolean quant = Integer.toString(i1).matches("[1-9]*");
		if(quant)
			return true;
		return false;
	}
}
