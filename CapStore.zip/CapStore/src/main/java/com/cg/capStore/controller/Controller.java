package com.cg.capStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capStore.bean.Cart;
import com.cg.capStore.bean.Products;
import com.cg.capStore.bean.CapUser;
import com.cg.capStore.exception.CartException;
import com.cg.capStore.service.CartService;


//@CrossOrigin(origins="http://localhost:4200")
@RestController
public class Controller 
{
	@Autowired
	CartService service;
	
	@GetMapping("/viewCart")
	public List<Cart> viewcartProducts()
	{
		return service.viewcartProducts();
	}
	
	@RequestMapping(value="/add" ,method=RequestMethod.POST)
	public void addToCart(@RequestBody Cart cart)
	{
		service.addToCart(cart);
	}
	
	@RequestMapping(value="/remove/{id}",method=RequestMethod.DELETE)
	public List<Cart> removeFromCart(@PathVariable int id)
	{
		
		return service.deleteFromCart(id);
	}
	
	@RequestMapping(value="/checkCart",method=RequestMethod.GET)
	public double checkCartValue()
	{
		return service.checkCartTotal();
	}
	
	@GetMapping("/viewProducts")
	public List<Products> viewAllProducts()
	{
		return service.viewProducts();
	}
	
	@RequestMapping(value="/placeOrder",method=RequestMethod.POST)
	public void placeOrder(@RequestBody CapUser user)
	{
		service.placeOrder(user);
	}
	
	
}
