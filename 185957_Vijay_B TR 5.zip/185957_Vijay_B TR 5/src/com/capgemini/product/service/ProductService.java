package com.capgemini.product.service;

import com.capgemini.product.beans.Order;

public interface ProductService {
	
	int calculateOrder(Order o);
}
