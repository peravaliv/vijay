package lab3;


import java.util.Scanner;

 public class MAin{
	public int getSecondSmallest(int[] ar)
	{
		for(int i=0;i<ar.length;i++)
		{
			for(int j=i+1;j<ar.length;j++)
			{
				if(ar[i]>ar[j])
					{
					int temp;
					temp=ar[i];
					ar[i]=ar[j];
					ar[j]=temp;
					
						
					}
						
			}
		
		
			}
		return ar[1];
		
	}
	
	

public static void main(String[] arg)
	{
	
	MAin m=new MAin();
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int [] a=new int[n];
	for(int i=0;i<n;i++)
	{
		a[i]=sc.nextInt();
		
	}
	int k=m.getSecondSmallest(a);
	System.out.println(k);
	}
 }

