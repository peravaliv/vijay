export class Cart 
{
public prod_id: number;
public prod_price: number;
 
}