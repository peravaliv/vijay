import{Mobile} from './mobile';


export class Basicphone extends Mobile{
  mobiletype:string;
  constructor(mobilebp)
  {
    super(1002,"Samsung",98765);
    this.mobiletype=mobilebp;

  }
  printMobileDetails()
  {
      super.printMobileDetails();
      console.log("Mobile Type of basic phone :"+this.mobiletype);
  }
}