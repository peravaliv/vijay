import { Component, OnInit } from '@angular/core';
import { TouchSequence } from 'selenium-webdriver';


import { Observable } from 'rxjs';
import { Product } from '../Product';
import { Service } from '../service.service';
@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {
  ProdList: any = [];
  s:any[]
  pro: Product = new Product();
  constructor(private proservice:Service) {
    this.proservice.getproDetails().subscribe(data => this.ProdList = data);
   }
  ngOnInit() {
  }
  
  searchprod(data)
  {
    
   this.s=this.proservice.search(data);
  }

}
