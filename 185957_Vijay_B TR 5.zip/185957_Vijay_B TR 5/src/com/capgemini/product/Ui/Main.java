package com.capgemini.product.Ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.product.validation.Validate;
import com.capgemini.product.beans.Order;
import com.capgemini.product.service.ProductService;
import com.capgemini.product.service.ProductServiceImpl;

public class Main {
	
	private static ProductService service = new ProductServiceImpl();
	private static Validate val = new Validate();
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in) ;
		Order or = new Order();
		
		int i;
		System.out.println("Enter The Product Details....!!!!\n");
		try
		{
			System.out.println("\tEnter the Name of Product:\t");
			String str = sc.next();
			if(val.name(str))
				or.setName(str);
			else {
				System.out.println("Enter valid Product name....!!!!");
				System.exit(0);
			}
			 System.out.println("\tEnter quantity:\t");
			 int i1 = sc.nextInt();
			 if(val.quant(i1)) {
			 do{
			 i = or.setQuantity(i1);		 
			 }while(i<1);
			 }
			 else {
					 System.out.println("Quantity should be greater than 1");
					 System.exit(0);
			 }
			 
			 System.out.println("\tEnter the PRICE (in dollars):\t");
			 or.setId((int) ((Math.random()* ((9999 - 1000) + 1)) + 1000));
			 or.setPrice(sc.nextDouble()); 
			 
			 service.calculateOrder(or);
		}
		catch(InputMismatchException e)
		{
			System.out.println("Enter correct value type");
		}
	}
}
