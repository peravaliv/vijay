package com.cg.capStore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.capStore.bean.Cart;

@Repository
public interface CartDao extends JpaRepository<Cart,Integer>
{
			
			@Query("select sum(prod_price) from Cart")
			int getCartSum();
		 

	
}
