package com.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.customer.bean.Customer1;
import com.customer.exception.CustomerException;
import com.customer.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerservice;
	@RequestMapping("/customers")
	public List <Customer1> getCustomer() throws CustomerException
	{
		return customerservice.getAllCustomer();
	}
	@RequestMapping(value="/customer", method=RequestMethod.POST)
	public List<Customer1> addCustomer(@RequestBody Customer1 cust) throws CustomerException{
		return customerservice.addCustomer(cust);
			}
	
	@RequestMapping("/customers/{id}")
	public Customer1 getCustomerById(@PathVariable int id) throws CustomerException{
	return customerservice.getCustomerById(id);
}
	
	@RequestMapping("/getCustomerByCity/city")
	public List <Customer1> findCustomerByCity(@RequestParam String city) throws CustomerException{
		return customerservice.getCustomerByCity(city) ;
	}
	@DeleteMapping("/customers/{id}")	
	public ResponseEntity<String> deleteCustomer(@PathVariable int id) throws CustomerException {
	customerservice.deleteCustomer(id);
	return new ResponseEntity<String> ("Customer with id "+id+" deleted",HttpStatus.OK);
	}
	
	@PutMapping("/customers/{id}")
	public List <Customer1> updateCustomer(@PathVariable int id, @RequestBody Customer1 cust) throws CustomerException{
		return customerservice.updateCustomer(id, cust);
	}
	
}