package com.capgemini.product.dao;

import com.capgemini.product.beans.Order;

public interface ProductDao {

	int saveOrder(Order o);

}
